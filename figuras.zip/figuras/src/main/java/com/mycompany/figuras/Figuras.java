package com.mycompany.figuras;

import java.util.Scanner;

// Interfaz Shape
interface Shape {
    double getArea();
    double getPerimeter();
    void setAttributes(Scanner scanner);
}

// Clase Circle
class Circle implements Shape {
    private double radius;

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public void setAttributes(Scanner scanner) {
        System.out.print("Ingrese el radio del círculo: ");
        radius = scanner.nextDouble();
    }
}

// Clase Triangle
class Triangle implements Shape {
    private double side1, side2, side3;

    @Override
    public double getArea() {
        double s = (side1 + side2 + side3) / 2;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    @Override
    public double getPerimeter() {
        return side1 + side2 + side3;
    }

    @Override
    public void setAttributes(Scanner scanner) {
        System.out.print("Ingrese los tres lados del triángulo separados por espacio: ");
        side1 = scanner.nextDouble();
        side2 = scanner.nextDouble();
        side3 = scanner.nextDouble();
    }
}

// Clase Square
class Square implements Shape {
    private double side;

    @Override
    public double getArea() {
        return side * side;
    }

    @Override
    public double getPerimeter() {
        return 4 * side;
    }

    @Override
    public void setAttributes(Scanner scanner) {
        System.out.print("Ingrese el lado del cuadrado: ");
        side = scanner.nextDouble();
    }
}

public class Figuras {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Seleccione la figura geométrica:");
            System.out.println("1. Círculo");
            System.out.println("2. Triángulo");
            System.out.println("3. Cuadrado");
            System.out.println("4. Salir");
            System.out.print("Opción: ");
            
            int option = scanner.nextInt();
            if (option == 4) {
                System.out.println("¡Hasta luego!");
                break;
            }
            
            Shape shape = null;
            switch (option) {
                case 1:
                    shape = new Circle();
                    break;
                case 2:
                    shape = new Triangle();
                    break;
                case 3:
                    shape = new Square();
                    break;
                default:
                    System.out.println("Opción inválida");
                    continue;
            }
            
            shape.setAttributes(scanner);
            
            System.out.println("Seleccione la propiedad a calcular:");
            System.out.println("1. Área");
            System.out.println("2. Perímetro");
            System.out.print("Opción: ");
            int propertyOption = scanner.nextInt();
            switch (propertyOption) {
                case 1:
                    System.out.println("Área: " + shape.getArea());
                    break;
                case 2:
                    System.out.println("Perímetro: " + shape.getPerimeter());
                    break;
                default:
                    System.out.println("Opción inválida");
            }
        }
        
        scanner.close();
    }
}
